library(testthat)
library(changeforest)

test_check("changeforest")
